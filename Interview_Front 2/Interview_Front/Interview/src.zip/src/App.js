import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './components/Home';
import Footer from './components/Footer';
import SignInRegister from './components/SignInRegister';
import ForgetPassword from './components/ForgetPassword';
import NewPassword from './components/NewPassword';
import Dashboard from './components/Dashboard';
import InterviewSimulation from './components/InterviewSimulation';
import JobDescription from './components/JobDescription';
import './App.css';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(true); // Assuming the user is logged in for demo purposes
  const [username, setUsername] = useState('Username'); // Replace with actual username

  return (
    <Router>
      <div className="App">
        <Navbar isLoggedIn={isLoggedIn} username={username} />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/signin" element={<SignInRegister />} />
          <Route path="/register" element={<SignInRegister />} />
          <Route path="/forget-password" element={<ForgetPassword />} />
          <Route path="/reset-password/:uidb64/:token" element={<NewPassword />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/interview-simulation" element={<InterviewSimulation />} />
          <Route path="/job-description" element={<JobDescription />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
