import React from 'react';
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import './Dashboard.css';

const responsive = {
  superLargeDesktop: {
    breakpoint: { max: 4000, min: 3000 },
    items: 3,
    partialVisibilityGutter: 60,
  },
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 3,
    partialVisibilityGutter: 60,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 2,
    partialVisibilityGutter: 50,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
    partialVisibilityGutter: 30,
  },
};

const CustomLeftArrow = ({ onClick }) => (
  <button className="arrow left-arrow" onClick={onClick}>
    {'<'}
  </button>
);

const CustomRightArrow = ({ onClick }) => (
  <button className="arrow right-arrow" onClick={onClick}>
    {'>'}
  </button>
);

const Dashboard = () => {
  const recommendedJobs = [
    'Job #1: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #2: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #3: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #4: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #5: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #5: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #5: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #5: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #5: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #5: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
    'Job #5: Lorem ipsum dolor sit amet, consectetur adipiscing elit',
  ];

  return (
    <div className="dashboard">
      <div className="carousel-container">
        <h2>Dashboard</h2>
        <Carousel
          responsive={responsive}
          infinite={true}
          partialVisible={true}
          showDots={false}
          customLeftArrow={<CustomLeftArrow />}
          customRightArrow={<CustomRightArrow />}
        >
          <div className="carousel-item">Box 1</div>
          <div className="carousel-item">Box 2</div>
          <div className="carousel-item">Box 3</div>
          <div className="carousel-item">Box 4</div>
          <div className="carousel-item">Box 5</div>
        </Carousel>
      </div>

      <div className="recommended-jobs">
        <h2>Recommended Jobs</h2>
        <div className="filters">
          <button className="filter-button">Filter 1</button>
          <button className="filter-button">Filter 2</button>
          <button className="filter-button">Filter 3</button>
          <button className="filter-button">Filter 4</button>
        </div>
        <div className="job-list">
          {recommendedJobs.map((job, index) => (
            <div key={index} className="job-item">
              {job}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
