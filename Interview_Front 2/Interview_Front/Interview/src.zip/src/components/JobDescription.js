import React from 'react';
import './JobDescription.css';

const JobDescription = () => {
  return (
    <div className="job-description-page">
      <header className="header">
        <div className="header-content">
          <h1>Job Title</h1>
          <p>Company Name</p>
          <p>Location</p>
          <button className="apply-button">Apply Now</button>
        </div>
      </header>
      <section className="job-details">
        <h2>Job Description</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce quis tellus nec dolor pellentesque gravida. Cras ac ligula luctus, molestie elit eget, tincidunt lorem. Aliquam non efficitur ligula.</p>
      </section>
      <section className="responsibilities">
        <h2>Responsibilities</h2>
        <ul>
          <li>Responsibility 1</li>
          <li>Responsibility 2</li>
          <li>Responsibility 3</li>
          <li>Responsibility 4</li>
        </ul>
      </section>
      <section className="requirements">
        <h2>Requirements</h2>
        <ul>
          <li>Requirement 1</li>
          <li>Requirement 2</li>
          <li>Requirement 3</li>
          <li>Requirement 4</li>
        </ul>
      </section>
      <section className="application-instructions">
        <h2>How to Apply</h2>
        <p>Follow these instructions to apply for the job.</p>
      </section>
    </div>
  );
};

export default JobDescription;
