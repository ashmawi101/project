import React, { useState, useEffect, useRef } from 'react';
import './InterviewSimulation.css';

const InterviewSimulation = () => {
  const [messages, setMessages] = useState([
    { text: 'Welcome to the interview simulation!', sender: 'system' },
    { text: 'Please introduce yourself.', sender: 'system' },
  ]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  const [audioChunks, setAudioChunks] = useState([]);
  const [audioContext, setAudioContext] = useState(null);
  const chatAreaRef = useRef(null);
  const canvasRef = useRef(null);

  const handleSendMessage = () => {
    if (input.trim()) {
      setMessages([...messages, { text: input, sender: 'user' }]);
      setInput('');
      // Add a system response here if needed
      setTimeout(() => {
        setMessages((prevMessages) => [
          ...prevMessages,
          { text: 'Thank you for your introduction.', sender: 'system' },
        ]);
      }, 1000);
    }
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSendMessage();
    }
  };

  const startRecording = () => {
    navigator.mediaDevices.getUserMedia({ audio: true })
      .then(stream => {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        setAudioContext(audioCtx);

        const source = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 2048;
        source.connect(analyser);

        const bufferLength = analyser.frequencyBinCount;
        const dataArray = new Uint8Array(bufferLength);

        const recorder = new MediaRecorder(stream);
        setMediaRecorder(recorder);

        recorder.ondataavailable = event => {
          setAudioChunks(prev => [...prev, event.data]);
        };

        recorder.onstop = () => {
          const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
          const audioUrl = URL.createObjectURL(audioBlob);
          setMessages(prevMessages => [
            ...prevMessages,
            { text: <audio controls src={audioUrl} />, sender: 'user' },
          ]);
          setAudioChunks([]);  // Reset audioChunks after stopping the recorder
        };

        recorder.start();
        setIsRecording(true);

        const canvas = canvasRef.current;
        const canvasCtx = canvas.getContext('2d');
        const WIDTH = canvas.width;
        const HEIGHT = canvas.height;

        const draw = () => {
          requestAnimationFrame(draw);
          analyser.getByteTimeDomainData(dataArray);

          canvasCtx.fillStyle = 'white';
          canvasCtx.fillRect(0, 0, WIDTH, HEIGHT);

          canvasCtx.lineWidth = 2;
          canvasCtx.strokeStyle = 'black';

          canvasCtx.beginPath();
          const sliceWidth = WIDTH * 1.0 / bufferLength;
          let x = 0;

          for (let i = 0; i < bufferLength; i++) {
            const v = dataArray[i] / 128.0;
            const y = v * HEIGHT / 2;

            if (i === 0) {
              canvasCtx.moveTo(x, y);
            } else {
              canvasCtx.lineTo(x, y);
            }

            x += sliceWidth;
          }

          canvasCtx.lineTo(canvas.width, canvas.height / 2);
          canvasCtx.stroke();
        };

        draw();
      })
      .catch(error => console.error('Error accessing microphone: ', error));
  };

  const stopRecording = () => {
    mediaRecorder.stop();
    setIsRecording(false);
    if (audioContext) {
      audioContext.close();
    }
  };

  useEffect(() => {
    if (chatAreaRef.current) {
      chatAreaRef.current.scrollTop = chatAreaRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div className="interview-simulation">
      <div className="header">
        <h2>Job Title</h2>
        <h3>Interview Simulation</h3>
        <p>Company Name</p>
      </div>
      <div className="chat-area" ref={chatAreaRef}>
        {messages.map((message, index) => (
          <div
            key={index}
            className={`message ${message.sender === 'user' ? 'user-message' : 'system-message'}`}
          >
            {message.text}
          </div>
        ))}
      </div>
      <div className="input-area">
        <canvas ref={canvasRef} className={`visualizer ${isRecording ? 'visible' : ''}`}></canvas>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Text Here"
        />
        <button onClick={handleSendMessage}>Send</button>
        {isRecording ? (
          <button onClick={stopRecording} className="record-button">Stop</button>
        ) : (
          <button onClick={startRecording} className="record-button">Record</button>
        )}
      </div>
    </div>
  );
};

export default InterviewSimulation;
