import React from 'react';
import './FeaturesSection.css';
import FeatureBox from './FeatureBox';

const FeaturesSection = () => {
  return (
    <div className="features-section">
      <h2>Features</h2>
      <h3>Find Your Dream Job</h3>
      <div className="features">
        <FeatureBox 
          title="AI-Powered Job Matching" 
          description="Find the best job matches using advanced AI algorithms." 
          icon="🤖"
        />
        <FeatureBox 
          title="Resume Optimization" 
          description="Get tips to improve your resume and increase your chances." 
          icon="📄"
        />
        <FeatureBox 
          title="Interview Preparation" 
          description="Practice common interview questions and get feedback." 
          icon="🎤"
        />
        <FeatureBox 
          title="Career Advice" 
          description="Receive personalized career advice from industry experts." 
          icon="💼"
        />
      </div>
    </div>
  );
};

export default FeaturesSection;
