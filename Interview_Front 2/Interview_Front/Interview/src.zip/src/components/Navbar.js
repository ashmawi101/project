import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Navbar.css';

const Navbar = ({ isLoggedIn, username }) => {
  const location = useLocation();
  const isInterviewSimulationPage = location.pathname === '/interview-simulation';

  return (
    <nav className="navbar">
      <div className="navbar-logo">
        <Link to="/">Hireme</Link>
      </div>
      {!isInterviewSimulationPage && (
        <div className="navbar-links">
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/jobs">Jobs</Link>
          <Link to="/interview-simulation">Interview Simulation</Link>
        </div>
      )}
      <div className="navbar-auth">
        {isLoggedIn ? (
          <button className="username-button">{username}</button>
        ) : (
          <>
            <Link to="/signin">Login</Link>
            <Link to="/register" className="register-button">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
