import React from 'react';
import './Home.css';
import FeaturesSection from './FeaturesSection';

const Home = () => {
  return (
    <div className="home">
      <div className="hero-section">
        <h1>Your AI Job Acquisition Assistant</h1>
        <div className="hero-buttons">
          <button className="get-started">Get Started</button>
          <button className="learn-more">Learn More</button>
        </div>
      </div>
      <FeaturesSection />
    </div>
  );
};

export default Home;
